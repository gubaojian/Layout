importClass("android.widget.Toast");


Toast.__c("makeText", activity, "\u4e2d\u6587", Toast.__g("LENGTH_SHORT")).__c("show");